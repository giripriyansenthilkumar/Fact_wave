document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.querySelector('form');
    const resultsSection = document.querySelector('.results-section');

    searchForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const category = document.getElementById('category').value.trim().toLowerCase(); // Convert to lowercase
        const keywords = document.getElementById('keywords').value.trim().toLowerCase(); // Convert to lowercase

        if (!category && !keywords) {
            alert('Please enter a category or keywords to search.');
            return;
        }

        try {
            const response = await fetch('/search', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ category, keywords })
            });

            if (response.ok) {
                const facts = await response.json();
                displayResults(facts);
            } else {
                resultsSection.innerHTML = '<p>No facts found matching the criteria.</p>';
            }
        } catch (error) {
            console.error('Error fetching search results:', error);
            resultsSection.innerHTML = '<p>An error occurred while searching. Please try again later.</p>';
        }
    });

    function displayResults(facts) {
        if (facts.length === 0) {
            resultsSection.innerHTML = '<p>No facts found matching the criteria.</p>';
            return;
        }

        const resultsList = document.createElement('ul');
        resultsList.innerHTML = facts.map(fact => `
            <li>
                <strong>Category:</strong> ${fact.category}<br>
                <strong>Description:</strong> ${fact.description}
            </li>
        `).join('');
        resultsSection.innerHTML = '';
        resultsSection.appendChild(resultsList);
    }
});

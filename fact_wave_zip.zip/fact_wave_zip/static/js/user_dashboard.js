const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition;
let transcriptionLines = [];
let isPaused = false;
let silenceTimer;

if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;  
    recognition.lang = 'en-US';
    recognition.maxAlternatives = 1;
} else {
    alert("Sorry, your browser doesn't support speech recognition.");
}

function startTranscription() {
    if (isPaused) {
        resumeTranscription();
    } else {
        isPaused = false; 
        recognition.start();
        displayTranscription("🎤 Listening...");
        toggleButtons("start"); 
    }

    recognition.onresult = (event) => {
        let interimTranscript = "";
        let finalTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) {
                finalTranscript += event.results[i][0].transcript + " ";
            } else {
                interimTranscript += event.results[i][0].transcript;
            }
        }

        if (finalTranscript) {
            addFinalTranscription(finalTranscript.trim());
            resetSilenceTimer(finalTranscript.trim()); 
        } else {
            updateCurrentTranscription(interimTranscript);
        }
    };

    recognition.onerror = (event) => {
        console.error("Speech Recognition Error:", event.error);
        displayTranscription("⚠ Error: " + event.error);
    };
}

function resetSilenceTimer(text) {
    clearTimeout(silenceTimer);
    silenceTimer = setTimeout(() => {
        saveTranscription(text);
    }, 5000); 
}

function stopTranscription() {
    recognition.stop();
    isPaused = true;
    displayTranscription("🛑 Stopped.");
    toggleButtons("stop");

    storeFinalText(transcriptionLines.join(" "));

    setTimeout(() => {
        window.location.reload();
    }, 1000); 
}

function togglePauseResume() {
    if (!isPaused) {
        recognition.stop();
        isPaused = true;
        document.getElementById("pause-btn").innerText = "Resume";
        displayTranscription("⏸ Paused...");
    } else {
        resumeTranscription();
    }
}

function resumeTranscription() {
    recognition.start();
    isPaused = false;
    document.getElementById("pause-btn").innerText = "Pause";
    displayTranscription("🎤 Listening...");
}

async function saveTranscription(text) {
    if (!text.trim()) return;

    try {
        let response = await fetch('/save_transcription', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ transcription: text })
        });

        let data = await response.json();
        console.log("Auto-Saved:", data);
    } catch (error) {
        console.error("Error saving:", error);
    }
}

async function storeFinalText(text) {
    try {
        let response = await fetch('/store-final-transcription', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ transcription: text })
        });

        let data = await response.json();
        console.log("Final Text Saved:", data);

        // ✅ Automatically trigger fact-checking after saving the final text
        setTimeout(checkFactStatus, 2000); 

    } catch (error) {
        console.error("Error saving final text:", error);
    }
}

function displayTranscription(text) {
    document.getElementById('transcription-text').innerText = text;
}

function updateCurrentTranscription(transcript) {
    document.getElementById('transcription-text').innerText = transcript;
}

function addFinalTranscription(transcript) {
    transcriptionLines.push(transcript);
    displayTranscription(transcriptionLines.join(" "));
}

function toggleButtons(action) {
    document.getElementById("start-btn").style.display = action === "start" ? "none" : "inline-block";
    document.getElementById("pause-btn").style.display = action === "start" ? "inline-block" : "none";
    document.getElementById("stop-btn").style.display = action === "start" ? "inline-block" : "none";
}

document.getElementById("stopButton").addEventListener("click", function() {
    stopTranscription();
});

async function checkFactStatus() {
    try {
        let response = await fetch('/fact-check', { method: 'GET' });
        let data = await response.json();

        console.log("Fact-Check Triggered:", data);

        setTimeout(updateFactStatus, 3000); // Wait & update status after checking
    } catch (error) {
        console.error("Error checking fact status:", error);
    }
}

async function updateFactStatus() {
    try {
        const response = await fetch('/fact-status');
        const data = await response.json();
        
        if (data.error) {
            document.getElementById("fact-status").innerHTML = "No status available.";
        } else {
            document.getElementById("fact-status").innerHTML = `
                <strong>Status:</strong> ${data.status} <br>
                <strong>Match Type:</strong> ${data.match_type} <br>
                <strong>Matched Fact:</strong> ${data.matched_fact || "N/A"}
            `;
        }
    } catch (error) {
        console.error("Error fetching fact status:", error);
    }
}

// 🔄 Refresh fact-check status every 5 seconds
setInterval(updateFactStatus, 5000);
import requests
import pymongo
import time

script_start = time.time()

# MongoDB Connection
client = pymongo.MongoClient("mongodb+srv://ml_dept_project:ml_dept_project@ml-project.gkigx.mongodb.net/")
db = client["factwave"]
collection = db["verified_facts"]

# Define expanded categories
categories = [
    "general", "politics", "sports", "business", "technology", "entertainment", 
    "health", "science", "world", "crime", "education", "weather"
]

# Get all stored headlines + categories for fast lookup
stored_news = set((doc.get("headline", ""), doc.get("category", ""))
                  for doc in collection.find({}, {"headline": 1, "category": 1, "_id": 0}))

API_KEY = "eff5ecc6ce7243179f9698ddda51f05e"
BASE_URL = "https://newsapi.org/v2/top-headlines?country=us&pageSize=10&category={}&apiKey=" + API_KEY

for category in categories:
    api_start = time.time()
    response = requests.get(BASE_URL.format(category))
    api_end = time.time()
    print(f"API response time for {category}: {api_end - api_start:.2f} seconds")

    news_data = response.json()

    process_start = time.time()
    if news_data["status"] == "ok":
        news_items = []
        for article in news_data["articles"]:
            headline = article["title"]  # Storing headline

            # Check if this headline + category already exists
            if headline and (headline, category) not in stored_news:
                news_items.append({ "category": category,"headline": headline})

        if news_items:
            insert_start = time.time()
            collection.insert_many(news_items)  # Bulk Insert
            insert_end = time.time()
            print(f"Inserted {len(news_items)} news items for {category} in {insert_end - insert_start:.2f} seconds")
        else:
            print(f"No new headlines to insert for {category}.")

    process_end = time.time()
    print(f"Processing time for {category}: {process_end - process_start:.2f} seconds")

script_end = time.time()
print(f"Total execution time: {script_end - script_start:.2f} seconds")

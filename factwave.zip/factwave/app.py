from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
import bcrypt
import datetime

app = Flask(__name__)

# Secret key for session management
app.secret_key = 'your_secret_key'  # Change this to a secret key

# MongoDB Configuration
app.config['MONGO_URI'] = 'mongodb://localhost:27017/factwave'  # Updated to point to the 'factwave' database
client = MongoClient(app.config['MONGO_URI'])

# Specify the 'factwave' database
db = client['factwave']  # This is the correct database name

# Collection names
users_collection = db['users']  # 'users' collection
transcriptions_collection=db['transcripted_text']
# Route for the Home Page (which is also the login page)
@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('admin_dashboard'))  # Redirect to the dashboard if already logged in
    return redirect(url_for('login'))  # If not logged in, redirect to the login page

# Route for Admin Dashboard
@app.route('/admin-dashboard')
def admin_dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated
    return render_template('admin_dashboard.html')

@app.route('/user-dashboard')
def user_dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated

    # Retrieve user data from the database (optional, depending on the user dashboard needs)
    username = session['username']
    user = users_collection.find_one({'username': username})

    if user:
        # Placeholder data for demonstration (you can replace this with actual dynamic content)
        transcription_data = [
            "This is a live broadcast of a news event.",
            "The stock market showed a significant increase today.",
            "The president announced new policies regarding taxes."
        ]

        flagged_statements = [
            {"text": "This is a live broadcast of a news event.", "severity": "low"},
            {"text": "The stock market showed a significant increase today.", "severity": "high"},
            {"text": "The president announced new policies regarding taxes.", "severity": "medium"}
        ]

        alerts = [
            {"statement": "This is a live broadcast of a news event.", "suggested_correction": "Verify the statement with official sources.", "severity": "low"},
            {"statement": "The stock market showed a significant increase today.", "suggested_correction": "Check with financial experts for accuracy.", "severity": "high"},
            {"statement": "The president announced new policies regarding taxes.", "suggested_correction": "Confirm with the White House for official confirmation.", "severity": "medium"}
        ]

        return render_template('user_dashboard.html', 
                               username=username, 
                               transcription_data=transcription_data, 
                               flagged_statements=flagged_statements,
                               alerts=alerts)
    else:
        return redirect(url_for('login'))  # If user is not found, redirect to login

@app.route('/check-text', methods=['POST'])
def check_text():
    data = request.get_json()  # Get JSON data from the request body
    text_to_check = data.get('text', '')  # Extract the text from the received data

    if not text_to_check:
        return jsonify({"message": "No text provided"}), 400

    # Search the database for the text
    existing_fact = facts_collection.find_one({"text": text_to_check})

    if existing_fact:
        return jsonify({"message": "Text found in the database"}), 200
    else:
        # If text is not found, return a custom alert message
        return jsonify({"message": "Text not found in the database. Please verify."}), 404

@app.route('/save-transcription', methods=['POST'])
def save_transcription():
    if 'username' not in session:
        return {"message": "Unauthorized"}, 401

    data = request.get_json()
    transcription_text = data.get('transcription', '')

    if transcription_text:
        # Save transcription to database
        users_collection.update_one(
            {'username': session['username']},
            {'$set': {'last_transcription': transcription_text}}
        )
        return {"message": "Transcription saved successfully"}, 200

    return {"message": "No transcription data provided"}, 400



# Route for Manage Users Page
@app.route('/manage-users')
def manage_users():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated
    
    users = users_collection.find()
    return render_template('manage-users.html', users=users)


@app.route('/add-user', methods=['GET', 'POST'])
def add_user():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        role=request.form['role']
        
        # Add user to MongoDB
        users_collection.insert_one({'username': username, 'password': password ,'role': role, 'email': email})
        
        flash("User added successfully!", "success")
        return render_template('add_user.html')

    return render_template('add_user.html')


# Route for deleting a user
@app.route('/delete-user/<user_id>', methods=['GET'])
def delete_user(user_id):
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated

    users_collection.delete_one({'_id': ObjectId(user_id)})
    return redirect(url_for('manage_users'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Find user in the database
        user = users_collection.find_one({'username': username})
        
        if user:
            # Compare the plain-text password
            if user['password'] == password:
                session['username'] = username  # Store username in session
                
                # Check user role and redirect accordingly
                if user.get('role') == 'admin':
                    return redirect(url_for('admin_dashboard'))  # Redirect to admin dashboard
                elif user.get('role') == 'user':
                    return redirect(url_for('user_dashboard'))  # Redirect to user dashboard
                else:
                    error_message = "Role not assigned. Please contact support."
                    return render_template('login.html', error_message=error_message)
            else:
                error_message = "Invalid password. Please try again."
        else:
            error_message = "Username not found. Please try again."
        
        return render_template('login.html', error_message=error_message)

    return render_template('login.html')
@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated

    if request.method == 'POST':
        if 'theme' in request.form:
            theme = request.form['theme']
            # Handle updating theme in the database or other storage
            flash("Theme updated successfully", "success")
        
        if 'language' in request.form:
            language = request.form['language']
            # Handle updating language settings in the database or config file
            flash("Language updated successfully", "success")
    
    return render_template('settings.html')
@app.route('/profile')
def view_profile():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated

    username = session['username']
    user = users_collection.find_one({'username': username})
    return render_template('profile.html', user=user)
@app.route('/change-password', methods=['GET', 'POST'])
def change_password():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated

    if request.method == 'POST':
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        # Fetch user from database
        username = session['username']
        user = users_collection.find_one({'username': username})

        # Verify current password
        if not (current_password, user['password']):
            return render_template('change_password.html', error="Incorrect current password")

        # Check if new passwords match
        if new_password != confirm_password:
            return render_template('change_password.html', error="New passwords do not match")

        # Hash the new password and update the database
        users_collection.update_one({'username': username}, {'$set': {'password': new_password}})

        return redirect(url_for('view_profile'))

    return render_template('change_password.html')

@app.route('/edit-profile', methods=['GET', 'POST'])
def edit_profile():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated

    username = session['username']
    user = users_collection.find_one({'username': username})

    if request.method == 'POST':
        updated_email = request.form['email']
        users_collection.update_one(
            {'username': username},
            {'$set': {'email': updated_email}}
        )
        flash("Profile updated successfully!", "success")
        return render_template('edit_profile.html', user=user)

    return render_template('edit_profile.html', user=user)


@app.route('/logout')
def logout():
    session.pop('username', None)  # Remove username from session
    return redirect(url_for('login'))
facts_collection = db.facts

# Route to display facts management page
@app.route('/manage-facts', methods=['GET'])
def manage_facts():
    facts = list(facts_collection.find())
    return render_template('manage_facts.html', facts=facts)

# Route to add a new fact
@app.route('/add-fact', methods=['POST'])
def add_fact():
    category = request.form.get('category')
    description = request.form.get('description')
    if category and description:
        facts_collection.insert_one({'category': category, 'description': description})
        flash('Fact added successfully!', 'success')
    else:
        flash('Category and Description are required.', 'error')
    return redirect(url_for('manage_facts'))

# Route to edit an existing fact
@app.route('/edit-fact', methods=['POST'])
def edit_fact():
    fact_id = request.form.get('fact_id')
    category = request.form.get('category')
    description = request.form.get('description')
    if fact_id and category and description:
        facts_collection.update_one(
            {'_id': ObjectId(fact_id)},
            {'$set': {'category': category, 'description': description}}
        )
        flash('Fact updated successfully!', 'success')
    else:
        flash('All fields are required.', 'error')
    return redirect(url_for('manage_facts'))

# Route to delete a fact
@app.route('/delete-fact/<fact_id>', methods=['POST'])
def delete_fact(fact_id):
    if fact_id:
        facts_collection.delete_one({'_id': ObjectId(fact_id)})
        flash('Fact deleted successfully!', 'success')
    return redirect(url_for('manage_facts'))

if __name__ == '__main__':
    app.run(debug=True)

// settings.js

document.addEventListener('DOMContentLoaded', function() {
    const themeSelector = document.getElementById('theme');
    const body = document.body;

    // Check if theme is stored in local storage
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.classList.add(savedTheme);
        themeSelector.value = savedTheme === 'light-theme' ? 'light' : 'dark';
    }

    // Update theme on selection
    themeSelector.addEventListener('change', function() {
        const selectedTheme = themeSelector.value === 'light' ? 'light-theme' : 'dark-theme';
        body.classList.remove('light-theme', 'dark-theme');
        body.classList.add(selectedTheme);
        
        // Save the selected theme to local storage
        localStorage.setItem('theme', selectedTheme);
    });
});

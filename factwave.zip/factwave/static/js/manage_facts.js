function editFact(id, category, description) {
    document.getElementById('editFactModal').style.display = 'flex';
    document.getElementById('editFactId').value = id;
    document.getElementById('editCategory').value = category;
    document.getElementById('editDescription').value = description;
}

function closeEditModal() {
    document.getElementById('editFactModal').style.display = 'none';
}

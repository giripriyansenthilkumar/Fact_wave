// Function to add a new custom alert dynamically under Alert Notifications
function addCustomAlert(alertText) {
    const alertsSection = document.getElementById('alerts-section');

    // Create a new alert div dynamically
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert';

    // Set a unique ID for the alert
    const uniqueId = `alert-${Date.now()}`;
    alertDiv.id = uniqueId;

    // Add the alert content
    const timestamp = new Date().toLocaleString();
    alertDiv.innerHTML = `
        <p><strong>Flagged:</strong> "${alertText}"</p>
        <p><small>Timestamp: ${timestamp}</small></p>
        <button onclick="resolveAlert('${uniqueId}')">Resolve</button>
    `;

    // Append the new alert to the alerts section
    alertsSection.appendChild(alertDiv);
}

// Function to resolve an alert
function resolveAlert(alertId) {
    const alertElement = document.getElementById(alertId);
    if (alertElement) {
        const resolvedAlertsList = document.getElementById('resolved-alerts-list');
        const alertText = alertElement.querySelector('p').textContent;

        // Add the resolved alert to the resolved list
        const resolvedItem = document.createElement('li');
        resolvedItem.textContent = `Resolved: ${alertText}`;
        resolvedAlertsList.appendChild(resolvedItem);

        // Remove the alert from the active alerts list
        alertElement.remove();
    }
}

// Example function to simulate adding alerts manually (you can remove or replace this with your own logic)
function simulateCustomAlerts() {
    setInterval(() => {
        const alertMessages = [
            "New message received.",
            "Important update pending.",
            "System alert: Action required.",
        ];
        const randomAlert = alertMessages[Math.floor(Math.random() * alertMessages.length)];
        addCustomAlert(randomAlert);  // Add a new alert with a random message
    }, 10000); // Trigger a new alert every 10 seconds for demo purposes
}

// Initialize the dashboard functionalities
function initializeDashboard() {
    // Start the simulated custom alerts
    simulateCustomAlerts();
}

// Wait for the DOM to load before initializing
document.addEventListener('DOMContentLoaded', initializeDashboard);
